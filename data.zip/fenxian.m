clear;
clc;

% 设置公共参数
k=0.2; theta=0.15; A1=1; C1=1; C2=2; C3=2; E1=20; E2=15; E3=3;
R1=37; R2=7; R3=5; lamda=1.5; gamma=0.88; r=0.75; tao=0.98;

% 设置不同的beta值
beta_values = [0.3, 0.5, 0.7, 0.9];
colors = ['r', 'g', 'b', 'm']; % 颜色数组
legend_entries = {};

figure(1);

% 对每个beta值进行仿真
for idx = 1:length(beta_values)
    beta = beta_values(idx);
    color = colors(idx);

    [t, y] = ode45(@(t, y) wechat(t, y, k, beta, theta, A1, C1, C2, C3, E1, E2, E3, R1, R2, R3, lamda, gamma, r, tao), [0 10], [0.5, 0.5]);
    
    % 绘制结果
    plot(t, y(:, 1), strcat('-', '+', color), 'LineWidth', 1);
    hold on;
    plot(t, y(:, 2), strcat('-', '^', color), 'LineWidth', 1);
    hold on;

    % 更新图例条目
    legend_entries{end+1} = ['government: \beta=', num2str(beta)];
    legend_entries{end+1} = ['enterprise: \beta=', num2str(beta)];
end

% 设置图表标签和图例
xlabel('Time (t)', 'Interpreter', 'latex');
ylabel('(p)', 'Interpreter', 'latex', 'Rotation', 0);
legend(legend_entries, 'Location', 'best');

% 设置坐标轴和网格线
axis([0 1 0 1]);
grid on;
set(gca, 'FontSize', 12, 'TickLabelInterpreter', 'latex');
