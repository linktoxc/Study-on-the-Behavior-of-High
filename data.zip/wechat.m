function dydt=wechat(t,y,k,beta,theta,A1,C1,C2,C3,E1,E2,E3,R1,R2,R3,lamda,gamma,r,tao)
%拆分
part0=((1-1/(1+exp(-k*(C2+A1)-1.69)))^r/(((1/(1+exp(-k*(C2+A1)-1.69)))^r+(1-1/(1+exp(-k*(C2+A1)-1.69)))^r))^(1/r));
part1=((y(2))^r)/(((y(2))^r+(1-y(2))^r)^(1/r));
part2=((1-y(2))^r)/(((y(2))^r+(1-y(2))^r)^(1/r));
part3=((beta)^r)/(((beta)^r+(1-beta)^r)^(1/r));
part4=((y(1))^r)/(((y(1))^r+(1-y(1))^r)^(1/r));
part5=((1-y(1))^r)/(((y(1))^r+(1-y(1))^r)^(1/r));
part6=((1/(1+exp(-k*(C2+A1)-1.69)))^r/(((1/(1+exp(-k*(C2+A1)-1.69)))^r+(1-1/(1+exp(-k*(C2+A1)-1.69)))^r))^(1/r));
%方程
dydt=zeros(2,1);
dydt(1)=y(1)*(1-y(1))*(part1*((E1+theta*R1)^gamma-lamda*(A1+C1+part0*part3*E3)^tao-(theta*R1)^gamma+lamda*(part0*part3*E3)^tao)-(part2*((E1+theta*R1)^gamma+lamda*(C1+part3*E3)^tao-(theta*R1)^gamma+lamda*(E3*part3)^tao)));
dydt(2)=y(2)*(1-y(2))*(part4*((A1+R1+part6*R2+E2+R3)^gamma-lamda*(C2+part0*part3*E3)^tao-(R1+R3)^gamma+lamda*(part3*C3+theta*R1)^tao)+part5*((R1+R2*part6+E2)^gamma-lamda*(C2+part0*part3*C3+theta*R1)^tao-R1^gamma-lamda*(part3*C3+theta*R1)^tao));
end